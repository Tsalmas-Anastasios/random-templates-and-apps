$('input').on('change', function() {
  $('body').toggleClass('blue');
});
