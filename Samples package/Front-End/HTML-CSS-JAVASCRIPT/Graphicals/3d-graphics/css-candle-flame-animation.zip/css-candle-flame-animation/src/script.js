// No image, pure CSS.
// Tried to make it as realistic as possible without using any javascript.
