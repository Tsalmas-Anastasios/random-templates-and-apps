<?php session_start();
unset($_SESSION["USER"]);
?>
<html>
<body>
	Thank you for visiting.
</body>
</html>