/***

This is a pure-CSS3 clock. It uses CSS animations and shapes, without any images or JavaScript.

***/