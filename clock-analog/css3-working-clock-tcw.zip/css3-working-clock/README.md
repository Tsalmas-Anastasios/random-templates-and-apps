# CSS3 Working Clock

A Pen created on CodePen.

Original URL: [https://codepen.io/iliadraznin/pen/AjWWQr](https://codepen.io/iliadraznin/pen/AjWWQr).

Working CSS3 analog clock, using CSS animations and shapes, without any images or JavaScript.

This is now available on GitHub @ https://github.com/iliadraznin/CSS3clock